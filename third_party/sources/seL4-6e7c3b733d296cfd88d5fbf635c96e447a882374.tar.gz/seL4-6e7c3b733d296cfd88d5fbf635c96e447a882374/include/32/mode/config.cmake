#
# Copyright 2020, Data61, CSIRO (ABN 41 687 119 230)
#
# SPDX-License-Identifier: GPL-2.0-only
#

add_bf_source_old("Kernel32" "shared_types.bf" "libsel4/mode_include/32" "sel4")
