//
// Copyright 2024, Colias Group, LLC
//
// SPDX-License-Identifier: BSD-2-Clause
//

#![no_std]
#![feature(used_with_arg)]

#[cfg(feature = "alloc")]
extern crate alloc;

mod channel;
mod defer;
mod handler;
mod message;
mod symbols;

// TODO
#[doc(hidden)]
pub mod ipc;

pub use channel::{Channel, Child, IrqAckError};
pub use defer::{DeferredAction, DeferredActionInterface, DeferredActionSlot};
pub use handler::{Handler, Infallible, Never, NullHandler};
pub use ipc::{ChannelSet, DisplayChannelSet};
pub use message::{
    MessageInfo, MessageLabel, MessageRegisterValue, get_mr, set_mr, with_msg_bytes,
    with_msg_bytes_mut, with_msg_regs, with_msg_regs_mut,
};
pub use symbols::{pd_is_passive, pd_name};

// For macros
#[doc(hidden)]
pub mod _private {
    pub use sel4_immutable_cell::ImmutableCell;
}
