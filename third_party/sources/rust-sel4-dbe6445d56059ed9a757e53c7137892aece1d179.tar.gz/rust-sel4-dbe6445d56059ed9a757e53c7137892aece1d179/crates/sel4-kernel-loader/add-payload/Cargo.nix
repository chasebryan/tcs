#
# Copyright 2023, Colias Group, LLC
#
# SPDX-License-Identifier: BSD-2-Clause
#

{ mk, localCrates, versions, serdeWith }:

mk {
  package.name = "sel4-kernel-loader-add-payload";
  dependencies = {
    inherit (versions)
      anyhow
      serde_json
      serde_yaml
      num
      object
      rkyv
      bitfield
    ;
    clap = { version = versions.clap; features = [ "derive" ]; };
    inherit (localCrates)
      sel4-patch-elf
      sel4-phdrs-constants
      sel4-kernel-loader-payload-types
    ;
    sel4-config-types = localCrates.sel4-config-types // { features = [ "serde" ]; };
    sel4-platform-info-types = localCrates.sel4-platform-info-types // { features = [ "owned" ]; };
  };
}
