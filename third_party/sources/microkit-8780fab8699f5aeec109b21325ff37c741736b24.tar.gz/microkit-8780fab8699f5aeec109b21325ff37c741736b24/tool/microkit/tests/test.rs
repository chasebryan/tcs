//
// Copyright 2024, UNSW
//
// SPDX-License-Identifier: BSD-2-Clause
//

use microkit_tool::{
    sdf,
    sel4::{self},
};
use serde_json::json;
use std::path::Path;

const DEFAULT_OBJECT_SIZES: sel4::ObjectSizes = sel4::ObjectSizes {
    tcb: 0,
    endpoint: 0,
    notification: 0,
    reply: 0,
    vspace: 0,
    page_table: 0,
    huge_page: 0,
    large_page: 0,
    small_page: 0,
    io_page_table: None,
    asid_pool: 0,
    vcpu: None,
};

const DEFAULT_AARCH64_KERNEL_CONFIG: sel4::Config = sel4::Config {
    arch: sel4::Arch::Aarch64,
    word_size: 64,
    minimum_page_size: 4096,
    paddr_user_device_top: 1 << 40,
    kernel_frame_size: 1 << 12,
    init_cnode_bits: 12,
    cap_address_bits: 64,
    max_num_bootinfo_untypeds: 230,
    fan_out_limit: 256,
    hypervisor: true,
    iommu: true,
    benchmark: false,
    num_cores: 1,
    num_domains: 16,
    num_domain_schedules: 100,
    fpu: true,
    arm_pa_size_bits: Some(40),
    arm_smc: None,
    riscv_pt_levels: None,
    // Not necessary for SDF parsing
    invocations_labels: json!(null),
    device_regions: None,
    normal_regions: None,
    object_sizes: DEFAULT_OBJECT_SIZES,
    address_space_constants: sel4::AddressSpaceConstants {
        page_table_index_bits: 9,
        vspace_index_bits: Some(10),
        io_page_table_index_bits: None,
        vspace_user_top: 0xffffffffff,
    },
};

const SMP_AARCH64_KERNEL_CONFIG: sel4::Config = sel4::Config {
    num_cores: 4,
    ..DEFAULT_AARCH64_KERNEL_CONFIG
};

const DEFAULT_X86_64_KERNEL_CONFIG: sel4::Config = sel4::Config {
    arch: sel4::Arch::X86_64,
    word_size: 64,
    minimum_page_size: 4096,
    paddr_user_device_top: 1 << 40,
    kernel_frame_size: 1 << 12,
    init_cnode_bits: 12,
    cap_address_bits: 64,
    max_num_bootinfo_untypeds: 230,
    fan_out_limit: 256,
    hypervisor: true,
    iommu: true,
    benchmark: false,
    num_cores: 1,
    num_domains: 16,
    num_domain_schedules: 100,
    fpu: true,
    arm_pa_size_bits: None,
    arm_smc: None,
    riscv_pt_levels: None,
    // Not necessary for SDF parsing
    invocations_labels: json!(null),
    device_regions: None,
    normal_regions: None,
    object_sizes: DEFAULT_OBJECT_SIZES,
    address_space_constants: sel4::AddressSpaceConstants {
        page_table_index_bits: 9,
        vspace_index_bits: None,
        io_page_table_index_bits: Some(9),
        vspace_user_top: 0x7fffffffefff,
    },
};

fn check_success(kernel_config: &sel4::Config, test_name: &str) {
    let env_path = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"));

    let mut prefill_path = env_path.clone();
    prefill_path.push("tests/prefills");

    let mut path = env_path.clone();
    path.push("tests/sdf/");
    path.push(test_name);
    let sdf = std::fs::read_to_string(path).unwrap();
    let parse = sdf::parse(
        Path::new(test_name),
        &sdf,
        kernel_config,
        &[prefill_path].to_vec(),
    );

    if let Err(ref e) = parse {
        eprintln!("Expected no error, instead got:\n{e}")
    }

    assert!(parse.is_ok());
}

fn check_error(kernel_config: &sel4::Config, test_name: &str, expected_err: &str) {
    let env_path = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"));

    let mut prefill_path = env_path.clone();
    prefill_path.push("tests/prefills");

    let mut sdf_path = env_path.clone();
    sdf_path.push("tests/sdf/");
    sdf_path.push(test_name);
    let sdf = std::fs::read_to_string(sdf_path).unwrap();
    let parse_err = sdf::parse(
        Path::new(test_name),
        &sdf,
        kernel_config,
        &[prefill_path].to_vec(),
    )
    .unwrap_err();

    if !parse_err.starts_with(expected_err) {
        eprintln!("Expected error:\n{expected_err}\nGot error:\n{parse_err}\n");
    }

    assert!(parse_err.starts_with(expected_err));
}

fn check_missing(kernel_config: &sel4::Config, test_name: &str, attr: &str, element: &str) {
    let expected_error =
        format!("Error: Missing required attribute '{attr}' on element '{element}'");
    check_error(kernel_config, test_name, expected_error.as_str());
}

#[cfg(test)]
mod memory_region {
    use super::*;

    #[test]
    fn test_malformed_size() {
        check_error(&DEFAULT_AARCH64_KERNEL_CONFIG, "mr_malformed_size.system", "Error: failed to parse integer '0x200_000sd' on element 'memory_region': invalid digit found in string")
    }

    #[test]
    fn test_unsupported_page_size() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_unsupported_page_size.system",
            "Error: page size 0x200001 not supported on element 'memory_region'",
        )
    }

    #[test]
    fn test_size_not_multiple_of_page_size() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_size_not_multiple_of_page_size.system",
            "Error: size is not a multiple of the page size on element 'memory_region'",
        )
    }

    #[test]
    fn test_addr_not_aligned_to_page_size() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_addr_not_aligned_to_page_size.system",
            "Error: phys_addr is not aligned to the page size on element 'memory_region'",
        )
    }

    #[test]
    fn test_missing_size() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_missing_size.system",
            "Error: size must be specified if memory region is not prefilled on element 'memory_region'",
        )
    }

    #[test]
    fn test_missing_name() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_missing_name.system",
            "name",
            "memory_region",
        )
    }

    #[test]
    fn test_invalid_attrs() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_invalid_attrs.system",
            "Error: invalid attribute 'page_count' on element 'memory_region': ",
        )
    }

    #[test]
    fn test_overlapping_phys_addr() {
        check_error(&DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_overlapping_phys_addr.system",
            "Error: memory region 'mr2' physical address range [0x9001000..0x9002000) overlaps with another memory region 'mr1' [0x9000000..0x9002000) @ ",
        )
    }

    #[test]
    fn test_mr_prefill_empty_file() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_prefill_empty_file.system",
            "Error: prefill file 'empty.bin' is empty on element 'memory_region'",
        )
    }

    #[test]
    fn test_mr_prefill_does_not_exists() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_prefill_does_not_exists.system",
            "Error: unable to find prefill file: 'abcxyz.bin' on element 'memory_region'",
        )
    }

    #[test]
    fn test_mr_prefill_size_without_prefill() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_prefill_size_without_prefill.system",
            "Error: 'setvar_prefill_size' used for MR without a `prefill_path` @",
        )
    }

    #[test]
    fn test_mr_prefill_no_size_valid() {
        check_success(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_prefill_no_size_valid.system",
        )
    }

    #[test]
    fn test_mr_prefill_page_sized_valid() {
        check_success(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_prefill_page_sized_valid.system",
        )
    }

    #[test]
    fn test_mr_prefill_sized_valid() {
        check_success(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "mr_prefill_sized_valid.system",
        )
    }

    #[test]
    fn test_mr_prefill_bootinfo_valid() {
        check_success(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "mr_prefill_bootinfo_valid.system",
        )
    }

    #[test]
    fn test_mr_prefill_bootinfo_type_invalid() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "mr_prefill_bootinfo_type_invalid.system",
            "Error: BootInfoMap type: 'x86_invalid_bootinfo' is not supported on element 'memory_region'",
        )
    }

    #[test]
    fn test_mr_prefill_path_bootinfo_both_specified() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "mr_prefill_path_bootinfo_both_specified.system",
            "Error: prefill_path and prefill_bootinfo cannot be both specified on element 'memory_region'",
        )
    }
}

#[cfg(test)]
mod protection_domain {
    use super::*;

    #[test]
    fn test_missing_name() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_missing_name.system",
            "name",
            "protection_domain",
        )
    }

    #[test]
    fn test_missing_program_image() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_missing_program_image.system",
            "Error: missing 'program_image' element on protection_domain: ",
        )
    }

    #[test]
    fn test_missing_path() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_missing_path.system",
            "path",
            "program_image",
        )
    }

    #[test]
    fn test_missing_mr() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_missing_mr.system",
            "mr",
            "map",
        )
    }

    #[test]
    fn test_missing_vaddr() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_missing_vaddr.system",
            "vaddr",
            "map",
        )
    }

    #[test]
    fn test_missing_irq_arm() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_missing_irq.system",
            "irq",
            "irq",
        );
    }

    #[test]
    fn test_missing_id() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_missing_id.system",
            "id",
            "irq",
        )
    }

    #[test]
    fn test_missing_symbol() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_missing_symbol.system",
            "symbol",
            "setvar",
        )
    }

    #[test]
    fn test_missing_region_paddr() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_missing_region_paddr.system",
            "region_paddr",
            "setvar",
        )
    }

    #[test]
    fn test_duplicate_setvar() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_duplicate_setvar.system",
            "Error: setvar on symbol 'test' already exists on element 'setvar': ",
        )
    }

    #[test]
    fn test_setvar_paddr_with_paddr() {
        check_success(&DEFAULT_X86_64_KERNEL_CONFIG, "pd_setvar_with_paddr.system")
    }

    #[test]
    fn test_setvar_paddr_no_paddr() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "pd_setvar_no_paddr.system",
            "Error: setvar with 'region_paddr' for MR without a specified paddr is unsupported on x86-64 @",
        )
    }

    #[test]
    fn test_duplicate_program_image() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_duplicate_program_image.system",
            "Error: program_image must only be specified once on element 'protection_domain': ",
        )
    }

    #[test]
    fn test_invalid_attrs() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_invalid_attrs.system",
            "Error: invalid attribute 'foo' on element 'protection_domain': ",
        )
    }

    #[test]
    fn test_program_image_invalid_attrs() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_program_image_invalid_attrs.system",
            "Error: invalid attribute 'foo' on element 'program_image': ",
        )
    }

    #[test]
    fn test_budget_gt_period() {
        check_error(&DEFAULT_AARCH64_KERNEL_CONFIG, "pd_budget_gt_period.system", "Error: budget (1000) must be less than, or equal to, period (100) on element 'protection_domain':")
    }

    #[test]
    fn test_irq_greater_than_max() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "irq_id_greater_than_max.system",
            "Error: id must be < 62 on element 'irq'",
        )
    }

    #[test]
    fn test_irq_less_than_0() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "irq_id_less_than_0.system",
            "Error: id must be >= 0 on element 'irq'",
        )
    }

    #[test]
    fn test_write_only_mr() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_write_only_mr.system",
            "Error: perms must not be 'w', write-only mappings are not allowed on element 'map':",
        )
    }

    #[test]
    fn test_irq_invalid_trigger() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "irq_invalid_trigger.system",
            "Error: trigger must be either 'level' or 'edge' on element 'irq'",
        )
    }

    #[test]
    fn test_irq_ioapic_on_arm() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "irq_ioapic_on_arm.system",
            "Error: x86 I/O APIC IRQ isn't supported on ARM and RISC-V on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_on_arm() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "irq_msi_on_arm.system",
            "Error: x86 MSI IRQ isn't supported on ARM and RISC-V on element 'irq'",
        )
    }

    #[test]
    fn test_irq_arm_on_x86() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_arm_on_x86.system",
            "Error: ARM and RISC-V IRQs are not supported on x86 on element 'irq'",
        )
    }

    #[test]
    fn test_irq_ioapic_less_than_0() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_ioapic_less_than_0.system",
            "Error: ioapic must be >= 0 on element 'irq'",
        )
    }

    #[test]
    fn test_irq_ioapic_pin_less_than_0() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_ioapic_pin_less_than_0.system",
            "Error: pin must be >= 0 on element 'irq'",
        )
    }

    #[test]
    fn test_irq_ioapic_invalid_trigger() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_ioapic_invalid_trigger.system",
            "Error: trigger must be either 'level' or 'edge' on element 'irq'",
        )
    }

    #[test]
    fn test_irq_ioapic_invalid_polarity() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_ioapic_invalid_polarity.system",
            "Error: polarity must be either 'low' or 'high' on element 'irq'",
        )
    }

    #[test]
    fn test_irq_ioapic_vector_less_than_0() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_ioapic_vector_less_than_0.system",
            "Error: vector must be within [0..107] on element 'irq'",
        )
    }

    #[test]
    fn test_irq_ioapic_vector_greater_than_107() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_ioapic_vector_greater_than_107.system",
            "Error: vector must be within [0..107] on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_pci_bus_less_than_0() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_msi_pci_bus_less_than_0.system",
            "Error: PCI bus must be within [0..255] on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_pci_dev_less_than_0() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_msi_pci_dev_less_than_0.system",
            "Error: PCI device must be within [0..31] on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_pci_func_less_than_0() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_msi_pci_func_less_than_0.system",
            "Error: PCI function must be within [0..7] on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_pci_bus_greater_than_255() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_msi_pci_bus_greater_than_255.system",
            "Error: PCI bus must be within [0..255] on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_pci_dev_greater_than_31() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_msi_pci_dev_greater_than_31.system",
            "Error: PCI device must be within [0..31] on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_pci_func_greater_than_7() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_msi_pci_func_greater_than_7.system",
            "Error: PCI function must be within [0..7] on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_handle_less_than_0() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_msi_handle_less_than_0.system",
            "Error: handle must be >= 0 on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_vector_less_than_0() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_msi_vector_less_than_0.system",
            "Error: vector must be within [0..107] on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_vector_greater_than_107() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_msi_vector_greater_than_107.system",
            "Error: vector must be within [0..107] on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_msi_pci_invalid() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "irq_msi_pci_invalid.system",
            "Error: expected PCI address in bus:device.function form on element 'irq'",
        )
    }

    #[test]
    fn test_irq_msi_msi_pci_valid() {
        check_success(&DEFAULT_X86_64_KERNEL_CONFIG, "irq_msi_pci_valid.system")
    }

    #[test]
    fn test_parent_has_id() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_parent_has_id.system",
            "Error: invalid attribute 'id' on element 'protection_domain': ",
        )
    }

    #[test]
    fn test_child_missing_id() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_child_missing_id.system",
            "id",
            "protection_domain",
        )
    }

    #[test]
    fn test_duplicate_child_id() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_duplicate_child_id.system",
            "Error: duplicate id: 0 in protection domain: 'parent' @",
        )
    }

    #[test]
    fn test_duplicate_child_id_vcpu() {
        check_error(&DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_duplicate_child_id_vcpu.system",
            "Error: duplicate id: 0 clashes with virtual machine vcpu id in protection domain: 'parent' @",
        )
    }

    #[test]
    fn test_small_stack_size() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_small_stack_size.system",
            "Error: stack size must be between",
        )
    }

    #[test]
    fn test_unaligned_stack_size() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_unaligned_stack_size.system",
            "Error: stack size must be aligned to the smallest page size",
        )
    }

    #[test]
    fn test_overlapping_maps() {
        check_error(&DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_overlapping_maps.system",
            "Error: map for 'mr2' has virtual address range [0x1000000..0x1001000) which overlaps with map for 'mr1' [0x1000000..0x1001000) in protection domain 'hello' @"
        )
    }

    #[test]
    fn test_overlapping_mixed_page_size_maps() {
        check_error(&DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_overlapping_mixed_page_sizes.system",
            "Error: map for 'small_region' has virtual address range [0x201000..0x202000) which overlaps with map for 'large_region' [0x200000..0x400000) in protection domain 'test' @"
        )
    }

    #[test]
    fn test_overlapping_x86_io_ports_1() {
        check_error(&DEFAULT_X86_64_KERNEL_CONFIG,
            "pd_overlapping_x86_io_ports_1.system",
            "Error: I/O port id: 1, half-open range: [0x3ff, 0x407) in protection domain: 'test1' @ pd_overlapping_x86_io_ports_1.system:8:5 overlaps with I/O port id: 0, half-open range: [0x3f8, 0x400) in protection domain: 'test1' @ pd_overlapping_x86_io_ports_1.system:8:5"
        )
    }

    #[test]
    fn test_overlapping_x86_io_ports_2() {
        check_error(&DEFAULT_X86_64_KERNEL_CONFIG,
            "pd_overlapping_x86_io_ports_2.system",
            "Error: I/O port id: 0, half-open range: [0x3ff, 0x407) in protection domain: 'test2' @ pd_overlapping_x86_io_ports_2.system:13:5 overlaps with I/O port id: 0, half-open range: [0x3f8, 0x400) in protection domain: 'test1' @ pd_overlapping_x86_io_ports_2.system:8:5"
        )
    }

    #[test]
    fn test_invalid_x86_io_port_size() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "pd_invalid_x86_io_port_size.system",
            "Error: size must be > 0 on element 'ioport':",
        )
    }

    #[test]
    fn test_invalid_cpu() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_invalid_cpu.system",
            "Error: cpu core must be less than 1, got 10 on element 'protection_domain':",
        )
    }
}

#[cfg(test)]
mod iommu {
    use super::*;

    #[test]
    fn test_iommu_missing_from_config() {
        check_error(
            &sel4::Config {
                iommu: false,
                ..DEFAULT_X86_64_KERNEL_CONFIG
            },
            "iommu_missing_from_config.system",
            "Error: io address space requires seL4 to be built with IOMMU support: ",
        );
    }

    #[test]
    fn test_iommu_missing_from_aarch64_config() {
        check_error(
            &sel4::Config {
                iommu: false,
                ..DEFAULT_AARCH64_KERNEL_CONFIG
            },
            "iommu_missing_from_config.system",
            "Error: io address space requires seL4 to be built with IOMMU support: ",
        );
    }

    #[test]
    fn test_iommu_missing_from_riscv64_config() {
        check_error(
            &sel4::Config {
                arch: sel4::Arch::Riscv64,
                iommu: false,
                ..DEFAULT_AARCH64_KERNEL_CONFIG
            },
            "iommu_missing_from_config.system",
            "Error: io address space requires seL4 to be built with IOMMU support: ",
        );
    }

    #[test]
    fn test_iommu_unsupported_on_aarch64() {
        check_error(
            &sel4::Config {
                iommu: true,
                ..DEFAULT_AARCH64_KERNEL_CONFIG
            },
            "iommu_missing_from_config.system",
            "Error: failed to parse device peripheral_id '0:3.0': IOMMU device identifiers are not supported on AArch64 on element 'io_address_space':",
        );
    }

    #[test]
    fn test_iommu_unsupported_on_riscv64() {
        check_error(
            &sel4::Config {
                arch: sel4::Arch::Riscv64,
                iommu: true,
                ..DEFAULT_AARCH64_KERNEL_CONFIG
            },
            "iommu_missing_from_config.system",
            "Error: failed to parse device peripheral_id '0:3.0': IOMMU device identifiers are not supported on RISC-V (64-bit) on element 'io_address_space':",
        );
    }

    #[test]
    fn test_out_of_bound() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_out_of_bound.system",
            "Error: iovaddr (0x8000000000) must be less than 0x8000000000 on element 'iomap': iommu_out_of_bound.system:10:9",
        )
    }

    #[test]
    fn test_range_out_of_bound() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_range_out_of_bound.system",
            "Error: iomap for 'region' has io address range [0x7fff800000..0x8000200000) which exceeds valid address space [0x0..0x8000000000) @",
        )
    }

    #[test]
    fn test_address_overflow() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_address_overflow.system",
            "Error: iomap for 'region' has address range that overflows @",
        )
    }

    #[test]
    fn test_valid_perms_and_bound() {
        check_success(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_valid_perms_and_bound.system",
        )
    }

    #[test]
    fn test_perms_read_write() {
        check_success(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_perms_read_write.system",
        )
    }

    #[test]
    fn test_perms_write_only() {
        check_success(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_perms_write_only.system",
        )
    }

    #[test]
    fn test_perms_execute_invalid() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_perms_execute_invalid.system",
            "Error: perms for io mapped memory must only be a combination of 'r' and 'w' on element 'iomap':",
        )
    }

    #[test]
    fn test_overlap_different_devices() {
        check_success(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_overlap_different_devices.system",
        )
    }

    #[test]
    fn test_overlap_same_device() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_overlap_same_device.system",
            "Error: map for 'region_b' has io address range [0x0..0x1000) which overlaps with map for 'region_a' [0x0..0x1000) in PCI device 00:03.0 @ iommu_overlap_same_device.system:12:9",
        )
    }

    #[test]
    fn test_same_mr_different_devices() {
        check_success(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_same_mr_different_devices.system",
        )
    }

    // Currently this test fails with "Error: currently seL4 does not have large page support for the IOMMU"
    // When seL4 supports large pages for the iommu it should fail with:
    // Error: map for 'small_region' has io address range [0x1000..0x2000) which overlaps with map for
    //'large_region' [0x0..0x200000) in PCI device 00:03.0 @ "
    #[test]
    fn test_overlap_mixed_page_sizes() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_overlap_mixed_page_sizes.system",
            "Error: currently seL4 does not have large page support for the IOMMU",
        )
    }

    #[test]
    fn test_pci_invalid() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_pci_invalid.system",
            "Error: failed to parse device peripheral_id '0:g.0': failed to parse PCI device on element 'io_address_space': iommu_pci_invalid.system:9:5",
        )
    }

    #[test]
    fn test_pci_negative_bus() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_pci_negative_bus.system",
            "Error: failed to parse device peripheral_id '-1:0.0': PCI bus must be within [0..255] on element 'io_address_space':",
        )
    }

    #[test]
    fn test_pci_negative_device() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_pci_negative_device.system",
            "Error: failed to parse device peripheral_id '0:-1.0': PCI device must be within [0..31] on element 'io_address_space':",
        )
    }

    #[test]
    fn test_pci_negative_function() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_pci_negative_function.system",
            "Error: failed to parse device peripheral_id '0:0.-1': PCI function must be within [0..7] on element 'io_address_space':",
        )
    }

    #[test]
    fn test_duplicate_device() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_duplicate_device.system",
            "Error: duplicate device name 'test_device' on element 'io_address_space':",
        )
    }

    #[test]
    fn test_duplicate_device_identifier() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_duplicate_device_identifier.system",
            "Error: duplicate device peripheral_id 'PCI device 00:03.0' on element 'io_address_space':",
        )
    }

    #[test]
    fn test_duplicate_domain_identifier() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "iommu_duplicate_domain_identifier.system",
            "Error: reusing a domain id is forbidden on element 'io_address_space'",
        );
    }
}

#[cfg(test)]
mod virtual_machine {
    use super::*;

    #[test]
    fn test_vm_valid_aarch64() {
        check_success(&DEFAULT_AARCH64_KERNEL_CONFIG, "vm_valid.system")
    }

    #[test]
    fn test_vm_with_priority_aarch64() {
        check_success(&DEFAULT_AARCH64_KERNEL_CONFIG, "vm_with_priority.system")
    }

    #[test]
    fn test_vm_valid_x86_64() {
        check_success(&DEFAULT_X86_64_KERNEL_CONFIG, "vm_valid.system")
    }

    #[test]
    fn test_vm_with_priority_x86_64() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "vm_with_priority.system",
            "Error: invalid attribute 'priority' on element 'virtual_machine'",
        )
    }

    #[test]
    fn test_vm_not_child() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "vm_not_child.system",
            "Error: virtual machine must be a child of a protection domain",
        )
    }

    #[test]
    fn test_duplicate_name() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "vm_duplicate_name.system",
            "Error: duplicate virtual machine name 'guest'",
        )
    }

    #[test]
    fn test_missing_vcpu() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "vm_missing_vcpu.system",
            "Error: missing 'vcpu' element on virtual_machine: ",
        )
    }

    #[test]
    fn test_missing_vcpu_id() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "vm_missing_vcpu_id.system",
            "id",
            "vcpu",
        )
    }

    #[test]
    fn test_invalid_vcpu_id() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "vm_invalid_vcpu_id.system",
            "Error: id must be < 62 on element 'vcpu'",
        )
    }

    #[test]
    fn test_overlapping_maps() {
        check_error(&DEFAULT_AARCH64_KERNEL_CONFIG,
            "vm_overlapping_maps.system",
            "Error: map for 'mr2' has virtual address range [0x1000000..0x1001000) which overlaps with map for 'mr1' [0x1000000..0x1001000) in virtual machine 'guest' @"
        )
    }

    #[test]
    fn test_missing_mr() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "vm_missing_mr.system",
            "Error: invalid memory region name 'mr1' on 'map' @",
        )
    }

    #[test]
    fn test_x86_ppc_invalid_1() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "vm_x86_ppc_invalid_1.system",
            "Error: It is not possible to PPC to PD 'VMM' with a bound vCPU from PD 'some_service' on x86_64",
        )
    }

    #[test]
    fn test_x86_ppc_invalid_2() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "vm_x86_ppc_invalid_2.system",
            "Error: It is not possible to PPC to PD 'VMM' with a bound vCPU from PD 'some_service' on x86_64",
        )
    }

    #[test]
    fn test_x86_ppc_valid() {
        check_success(&DEFAULT_X86_64_KERNEL_CONFIG, "vm_x86_ppc_valid.system")
    }

    #[test]
    fn test_vm_x86_vm_with_child_invalid() {
        check_error(
            &DEFAULT_X86_64_KERNEL_CONFIG,
            "vm_x86_vm_with_child_invalid.system",
            "Error: It is not possible for PD 'VMM' with a bound vCPU to have children on x86_64",
        )
    }
}

#[cfg(test)]
mod channel {
    use super::*;

    #[test]
    fn test_missing_id() {
        check_missing(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_missing_id.system",
            "id",
            "end",
        )
    }

    #[test]
    fn test_id_greater_than_max() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_id_greater_than_max.system",
            "Error: id must be < 62 on element 'end'",
        )
    }

    #[test]
    fn test_id_less_than_0() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_id_less_than_0.system",
            "Error: id must be >= 0 on element 'end'",
        )
    }

    #[test]
    fn test_invalid_attrs() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_invalid_attrs.system",
            "Error: invalid attribute 'foo' on element 'channel': ",
        )
    }

    #[test]
    fn test_channel_invalid_pd() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_invalid_pd.system",
            "Error: invalid PD name 'invalidpd' on element 'end': ",
        )
    }

    #[test]
    fn test_invalid_element() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_invalid_element.system",
            "Error: invalid XML element 'ending': ",
        )
    }

    #[test]
    fn test_not_enough_ends() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_not_enough_ends.system",
            "Error: exactly two end elements must be specified on element 'channel': ",
        )
    }

    #[test]
    fn test_too_many_ends() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_too_many_ends.system",
            "Error: exactly two end elements must be specified on element 'channel': ",
        )
    }

    #[test]
    fn test_end_invalid_pp() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_end_invalid_pp.system",
            "Error: pp must be 'true' or 'false' on element 'end': ",
        )
    }

    #[test]
    fn test_end_invalid_notify() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_end_invalid_notify.system",
            "Error: notify must be 'true' or 'false' on element 'end': ",
        )
    }

    #[test]
    fn test_bidirectional_ppc() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_bidirectional_ppc.system",
            "Error: cannot ppc bidirectionally on element 'channel': ",
        )
    }

    #[test]
    fn test_ppcall_priority() {
        check_error(&DEFAULT_AARCH64_KERNEL_CONFIG,
            "ch_ppcall_priority.system",
            "Error: PPCs must be to protection domains of strictly higher priorities; channel with PPC exists from pd test1 (priority: 2) to pd test2 (priority: 1)",
        )
    }
}

#[cfg(test)]
mod domains {
    use super::*;

    #[test]
    fn test_domain_smp() {
        check_error(
            &SMP_AARCH64_KERNEL_CONFIG,
            "domain_smp.system",
            "Error: The domain scheduler is not supported in multicore builds of seL4",
        )
    }

    #[test]
    fn test_domain_too_many_domains() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "domain_exceed_max_domains.system",
            "Error: Number of domains exceeds 16 on element 'domains': domain_exceed_max_domains.system:8:5",
        )
    }

    #[test]
    fn test_domain_assign_pd_to_invalid_domain() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "domain_assign_pd_to_invalid_domain.system",
            "Error: domain 'domain_2' not declared in <domains>: on element 'protection_domain': domain_assign_pd_to_invalid_domain.system:16:5",
        )
    }

    #[test]
    fn test_domain_invalid_timeslice() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "domain_invalid_timeslice.system",
            "Error: The duration '1000 kilometres' must be in either 'ticks' or 'us' on element 'schedule_entry': domain_invalid_timeslice.system:12:13"
        )
    }

    #[test]
    fn test_domain_no_schedule() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "domain_no_schedule.system",
            "Error: Specifying a domain 'domain_1' without declaring a domain schedule is not allowed: on element 'protection_domain': domain_no_schedule.system:8:5",
        )
    }

    #[test]
    fn test_domain_pd_no_domain() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "domain_no_pd_domain.system",
            "Error: Missing required attribute 'domain' on element 'protection_domain': domain_no_pd_domain.system:15:5",
        )
    }

    #[test]
    fn test_domain_invalid_start_index() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "domain_invalid_start_index.system",
            "Error: failed to parse integer 'zzzz' on element 'domain_schedule': invalid digit found in string",
        )
    }

    #[test]
    fn test_domain_out_of_bounds_start_index() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "domain_out_of_bounds_start_index.system",
            "Error: schedule_start_index '1' is greater than the length of the schedule '1' \
             on element 'domain_schedule': domain_out_of_bounds_start_index.system:11:9",
        )
    }

    #[test]
    fn test_domain_invalid_shift() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "domain_invalid_shift.system",
            "Error: failed to parse integer 'zzzz' on element 'domain_schedule': invalid digit found in string",
        )
    }

    #[test]
    fn test_domain_out_of_bounds_shift() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "domain_out_of_bounds_shift.system",
            "Error: schedule_index_shift '0' on top of the schedule length '1' would \
             exceed than the configured KernelNumDomainSchedules 100 \
             on element 'domain_schedule': domain_out_of_bounds_shift.system:11:9",
        )
    }
}

#[cfg(test)]
mod system {
    use super::*;

    #[test]
    fn test_duplicate_pd_names() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_duplicate_pd_name.system",
            "Error: duplicate protection domain name 'test'.",
        )
    }

    #[test]
    fn test_duplicate_mr_names() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_duplicate_mr_name.system",
            "Error: duplicate memory region name 'test'.",
        )
    }

    #[test]
    fn test_duplicate_irq_number() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_duplicate_irq_number.system",
            "Error: duplicate irq: 112 in protection domain: 'test2' @ ",
        )
    }

    #[test]
    fn test_duplicate_irq_id() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_duplicate_irq_id.system",
            "Error: duplicate channel id: 3 in protection domain: 'test1' @",
        )
    }

    #[test]
    fn test_channel_duplicate_a_id() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_channel_duplicate_a_id.system",
            "Error: duplicate channel id: 5 in protection domain: 'test1' @",
        )
    }

    #[test]
    fn test_channel_duplicate_b_id() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_channel_duplicate_b_id.system",
            "Error: duplicate channel id: 5 in protection domain: 'test2' @",
        )
    }

    #[test]
    fn test_no_protection_domains() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_no_protection_domains.system",
            "Error: at least one protection domain must be defined",
        )
    }

    #[test]
    fn test_text_elements() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_text_elements.system",
            "Error: unexpected text found in element 'system' @",
        )
    }

    #[test]
    fn test_map_invalid_mr() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_map_invalid_mr.system",
            "Error: invalid memory region name 'foos' on 'map' @ ",
        )
    }

    #[test]
    fn test_map_not_aligned() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_map_not_aligned.system",
            "Error: invalid vaddr alignment on 'map' @ ",
        )
    }

    #[test]
    fn test_map_too_high() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_map_too_high.system",
            "Error: vaddr (0x1000000000000000) must be less than 0xffffffc000 on element 'map'",
        )
    }

    #[test]
    fn test_map_range_too_high() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_map_range_too_high.system",
            "Error: map for 'foo' has virtual address range [0xe000000000..0x200e000000000) which exceeds valid address space",
        )
    }

    #[test]
    fn test_too_many_pds() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "sys_too_many_pds.system",
            "Error: too many protection domains (64) defined. Maximum is 63.",
        )
    }

    #[test]
    fn test_fpu_flag_wrong_value() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "wrong_fpu_flag_value.system",
            "Error: fpu must be 'true' or 'false'",
        )
    }

    #[test]
    fn test_cap_mappings_overlapping() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_cap_mappings_overlapping.system",
            r#"Error: overlapping user caps in slot 3 of protection domain 'pd_b':
  type VSpace from 'pd_a' at 'pd_cap_mappings_overlapping.system:23:13'
  type VSpace from 'pd_a' at 'pd_cap_mappings_overlapping.system:25:13'"#,
        )
    }

    #[test]
    fn test_cap_mappings_slot_invalid() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "cap_mappings_slot_invalid.system",
            "Error: The destination slot 0 has been reserved for Microkit CNode on element 'cap_sc'",
        )
    }

    #[test]
    fn test_cap_mappings_invalid() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_cap_mappings_invalid.system",
            "Cap type: 'gerbils' is not supported at 'pd_cap_mappings_invalid.system:16:13'",
        )
    }

    #[test]
    fn test_cap_mappings_invalid_pd_ref() {
        check_error(
            &DEFAULT_AARCH64_KERNEL_CONFIG,
            "pd_cap_mappings_invalid_pd_ref.system",
            "Error: unknown PD name 'invalid': pd_cap_mappings_invalid_pd_ref.system:12:13",
        )
    }
}
