# Revision History for Microkit

## Release 2.3.0

This release contains quite a few new features:

  * x86_64 IOMMU support (this entails a breaking change)
  * seL4_BootInfo support, for reading runtime parameters on x86_64
  * Various improvements to x86_64 virtual machines, such as being able to
    stop/start their execution.
  * Support for 'Cap Sharing' to give PDs access to specific TCBs or SCs,
    useful for userspace schedulers.
  * Support for the seL4 Domain Scheduler.

There are also a variety of bug fixes, especially for x86_64 systems, and
support for two new boards.

### Breaking changes

* x86_64 systems are now built with the IOMMU turned on by default, as we have
  added new syntax to allow for the IOMMU to be configured (see below).
  However, previously the IOMMU was disabled in seL4, so systems which did DMA
  on x86_64 will now *stop working* without specifying the IOMMU setup.

* x86_64 IOAPIC IRQs had an inverted polarity; `polarity="low"` became high
  and `polarity="high"` became low.

* vCPUs now default to the same core as the VMM, instead of core 0. If you
  were relying on this behaviour, you should explicitly specify core 0.

* PCI 'bus:dev:func' syntax is no longer supported, use the correct 'bus:dev.func'
  syntax instead. This was an implementation bug which was more permissive
  than it was supposed to be.

* Virtual Machines on x86_64:

  * No longer support budget/period/priority. This did not work previously,
    as they share a TCB/SC with the VMM.

  * The VMM on x86_64 cannot have children, nor receive PPCs.
    This was previously allowed but had several complex restrictions (such as
    not receiving messages after a `vmenter`) so have been disallowed.

* If you were not using the `libmicrokit` linker script (e.g. rust-seL4 users),
  the `__sel4_ipc_buffer_obj` is no longer declared in the linker script, and
  is instead allocated by the tool at a fixed virtual address above the stack
  which is now reserved. If you were assuming a specific virtual address for the
  IPC buffer, this would be broken.

### Feature changes

* Update to 16.0.0 release of seL4.

* Support an 'fpu' attribute on protection domains, following [RFC-18](
  https://sel4.github.io/rfcs/implemented/0180-fpu-switching.html), which allows
  for FPU access to be disabled on a per-PD basis.

* The debug-only (unverified) HardwareDebugAPI has been enabled and is available
  on most x86_64 and AArch64 platforms.

* A new 'cap sharing' feature. The SDF now supports a `<cspace>` element and
  support for placing caps to TCBs, SchedContexts, and VSpaces of other PDs
  into the CSpace of the current PD. This can be useful for user space schedulers
  that are not the fault-handlers (i.e. use parent-child hierarchy).

* It is now possible to turn x86 vCPUs (VMs) on or off.
  Use the new `microkit_vcpu_x86_on` and `microkit_vcpu_x86_off` APIs

* AArch64 EL1 (non-hypervisor) platforms are now supported.

* There is a new (experimental) `--viper-output` argument to the tool, which
  is part of some new (experimental) verification work of Microkit PDs using
  the [Viper tools from ETH Zürich](http://viper.ethz.ch).

* Microkit PDs are now a 2-level CSpace. This should not have any impact on
  users.

* It is now possible to create memory regions that are prefilled with bootinfo
  from the capDL initialiser. This includes the VBE, MBMAP, ACPI RSDP, Framebuffer,
  and TSC frequency types exported by seL4.

* New function `microkit_pd_resume()` which resumes a stopped child PD. Previously,
  only stop and start (which does resume but requires a program counter) existed.

* New support for configuring the IOMMU on x86_64 systems with the
  `<io_address_space>` element. See the `x86_64_iommu_dma_test` example packaged
  in the SDK for more details, as well as the manual section on IOMMU.
  Only 4KiB pages are supporting for the IOMMU due to kernel limitations.

* Support for the seL4 domain schedule now that the [RFC-20 Runtime Schedules](
  https://sel4.github.io/rfcs/implemented/0200-domain-schedules.html) has been
  added to seL4. This is useful for systems which want isolated subsystems
  with limited information flow between them.

### Bug fixes

* TQMA8XQP1GB loader address has been fixed as it was collided with reserved
  regions in memory.
* IOAPIC IRQ polarity was inverted.
* The loader now only maps in the loader memory, UART, and kernel regions, as
  otherwise (instruction) speculative accesses to device memory can occur.
  Please see [PR 464 for more details](https://github.com/seL4/microkit/pull/464).
* A `microkit_deferred_notify()` or `microkit_deferred_irq_ack()` would be
  lost if you sent a reply from a `protected()` call, or from a `fault()` handler.
  Now we perform `seL4_Send` on the Notification or IRQHandler capability
  before replying to the PPC or Fault.
* A bug with [high-address regions allocated the wrong memory](
  https://github.com/seL4/rust-sel4/issues/319) in the capDL initialiser was
  fixed.
* A bug with certain systems that caused the Microkit tool to panic with the
  below message has been fixed.

  ```
  thread 'main' (414114) panicked at tool/microkit/src/capdl/allocation.rs:225:17:
  assertion `left == right` failed
  ```

### Board support

* 'stm32mp2' for the STM32MP2 evaluation board.
* 'qemu_virt_aarch64_el1' for QEMU/KVM on Linux AArch64 hosts (which don't support
   nested virtualisation).

### Notes for developers

* There is a new `--override-kernel` option to the tool that allows one to
  use an SDK build of Microkit but with a different seL4 kernel ELF.
* We now have basic CI that runs Microkit images on real hardware.
* We now recommend the use of the [Google repo-manifest 'microkit-manifest'](
  https://github.com/seL4/microkit-manifest) which tracks the supported version
  of seL4 to be used for testing the Microkit. It also records the latest build
  of the main branch which passed CI.

## Release 2.2.0

This release contains various bug fixes, minor features, and new board support.

There are no breaking changes.

### Feature changes

* Update to seL4 15.0.0.
* Support passing a separate ELF file used for symbol patching for PD program images.
  See the manual section on the `program_image` element for details.
* Support memory regions that are prefilled with data upon initialisation.
* Update flake to Nix 25.11.

### Bug fixes

* Fix version of uImage header emitted.
* Fix regressions from 2.1.0 that caused Raspberry Pi 4B to fail to boot.
* Fix false-positive error message when using setvar with memory regions that do not
  have an explicit physical address.
* Fix ELF image output to include empty string table, certain tools such as objcopy
  were complaining that the ELF was invalid.
* Fix some memory ranges overlapping false-positivies in the tool.
* Formatting fixes to libmicrokit's provided `__assert_fail`. It is now a weakly
  declared function so users can overwrite it with their own implementation.
* Fix internal bug that can cause initialisation to fail on ARM with the benchmarking configuration.
* Fix passive PD initialisation sometimes failing. There is still a possible race
  condition on SMP configurations, but single-core is fixed.
  See https://github.com/seL4/microkit/issues/91 for details.

### Board support

* Radxa ROCK 3B
* AMD Kria K26 SOM (based on the ZCU102)

## Release 2.1.0

This release contains various bug fixes, quality-of-life changes, features, and new board support.

There are no breaking changes.

### Feature changes

* Initial x86-64 support.
    * This means that Microkit now supports all 64-bit architectures of seL4.
* Transition to using capDL for system initialisation.
    * While this is a significant internal change, there should be no
      difference for users of Microkit.
    * However, this does mean we can now mark the seL4 RFC for Microkit as
      'implemented'!
* Update to 14.0.0 of seL4.
    * With the changes for the transition to capDL, we no longer need patches to the kernel.
* Add support for multi-core systems on all platforms.
    * For now, the default configurations of Microkit are still using the uni-core
      variant of seL4. A different value to `--config` is required to use the
      SMP variant.
    * See the [manual section](https://github.com/seL4/microkit/blob/2.1.0/docs/manual.md#multi-core-smp-configurations-multicore_config)
      for more details.
* Add new `setvar_id` attribute similar to `setvar_vaddr` but for any system description
  elements that have an identifier associated with them (e.g channel ends).
* Add new `--image-type` argument to the tool to specify system image format
  that will be produced.
    * For ARM and RISC-V support we have only supported emitting a raw binary. We now support
      ELFs and (on RISC-V) the uImage format.
    * On RISC-V platforms, when booting with U-Boot (e.g on the Star64) the binary format does
      not receive the expected arguments for booting (hart ID). The binary was working by coincidence
      and only for the uImage Linux format does U-Boot pass the hart ID when booting the image. For
      this reason all RISC-V hardware platforms (other than our supported FPGA platforms) default to
      uImage now to prevent booting issues.
    * See the [manual section](https://github.com/seL4/microkit/blob/2.1.0/docs/manual.md#image-format)
      for all details.
* Enable `KernelAllowSMCCalls` by default for all ARM platforms.
    * This means that all Microkit systems can make use of the PD SMC feature by default
      rather than having to change the kernel configuration and then build the SDK from source.
* Increase the default PD stack size from 0x1000 to 0x2000.
* Add different memory configurations for Raspberry Pi 4B.
    * Previously only 1GB was supported, now 2GB, 4GB and 8GB variants are available.
* Support building the SDK using LLVM instead of GCC.
    * GCC still remains the default for now, but this does give the option
      for people to use LLVM when building Microkit from source.
* Default to using Python 3.12 when building from source.
* Update Nix flake to use Nix 25.05.

### Bug fixes

* Fixed the libmicrokit linker script to avoid the IPC buffer symbol potentially
  overlapping with loadable segments.
* Fixes and improvements to error checking on the system description.
* Add missing `inline` to certain libmicrokit calls to fix warnings on newer C
  compilers.

### Board support

* Compulab IOT-GATE-IMX8PLUS
* Serengeti
* SiFive Premier P550
* Ultra96v2
* x86-64 generic targets

### Upgrade notes

There are no breaking changes in this release, but for users it is important to
note that there was a significant internal change (transition to capDL) that may
lead to regressions.

We have fixed all regressions that we have found, but there may be some we
have missed. If you notice any unexpected behaviour, please
[open an issue on GitHub](https://github.com/seL4/microkit/issues).

Due to the capDL changes, the boot log output has slightly changed, so if you have scripts
that rely on the certain debug UART output you might have to update them.

Instead of this boot log:

```
Booting all finished, dropped to user space
MON|INFO: Microkit Bootstrap
MON|INFO: bootinfo untyped list matches expected list
MON|INFO: Number of bootstrap invocations: 0x0000000a
MON|INFO: Number of system invocations:    0x00000228
MON|INFO: completed bootstrap invocations
MON|INFO: completed system invocations
```

you'll instead see this:

```
Booting all finished, dropped to user space
INFO  [sel4_capdl_initializer::initialize] Starting CapDL initializer
INFO  [sel4_capdl_initializer::initialize] Starting threads
MON|INFO: Microkit Monitor started!
```

before your Microkit system starts.

## Release 2.0.1

This release contains various bug fixes. It does not include any new features.

* Fixed a regression introduced in 2.0.0 when using channel numbers greater than 32.
* Fixed building SDK on Linux AArch64 hosts.
* Fixed loader output to always output return character before newline.
* Fixed loader to initialise UART for QEMU virt AArch64 to silence warnings
  when using `-d guest_errors`.
* Report error when user-specified PD mappings overlap with it's own ELF
  or stack region.
* Included kernel bug-fix that prevented Raspberry Pi 4B booting correctly.

## Release 2.0.0

This release contains various bug fixes, quality-of-life changes, features, and
new board support.

This is a major version bump due to a breaking change. Below the release notes,
there is a section on how to upgrade from Microkit 1.4.1.

### Features

* Add support for virtual machines with multiple vCPUs.
* Add support for ARM platforms to use SMC forwarding.
    * Note that this requires a kernel option to be set that right now is not
      set by default on any ARM platforms in Microkit.
* Allow tool to target Linux AArch64 hosts, also available as a pre-built SDK
  starting in this release.
* Increase max PD name length to 64 characters (from 16).
* Add Nix flake for Nix users who want to build from source and not depend on
  the pre-built SDK.
* Allow specifying whether a channel end can notify the other.
* Memory Regions now default to the largest possible page size for the MR's size
  and alignment of virtual addresses of its mappings.
    * This is transparent to users, but can lead to improved performance and
      memory usage.
* Utilise kernel API for naming threads in debug mode.
    * Helps debugging any kernel error prints in certain cases.
* Monitor fault handling now prints if a virtual memory exception was likely due
  to a PD stack overflow.
* Monitor fault handling now decodes user-exceptions likely caused by LLVM's
  UBSAN and prints appropriate debug output (only on AArch64).
* Add `setvar_size` attribute for MR mappings, similar to `setvar_vaddr`.
* Add a new 'Internals' section in the manual to document how the Microkit
  actually works.
* libmicrokit APIs for notifying, IRQ acking and performing PPCs now print
  errors when an invalid channel is used in debug mode.
    * Previously this lead to a kernel error print that was not that useful from
      within a Microkit environment.
* System images are now relocatable.
    * Previously they required loading at particular address within physical
      memory, the Microkit loader will now relocate itself if loaded at a
      different range of physical memory. This can make the boot-loading process
      of Microkit images less fragile.

### Bug fixes

* Allow mapping in 'null' page. Necessary for virtual machines with guest memory
  that starts at guest physical address zero.
* More error checking for invalid mappings (e.g virtual address outside of valid
  range).
* Re-add warning for unused memory regions.
    * This is a bug fix since it used to be part of the tool before it was rewritten.
* Actually enforce the PPC priority rule that PPC is only allowed to PDs of higher
  priority.
    * Note that to fix this in the tool, we had to introduce a breaking change
      in the SDF. See upgrade notes for details.
* Fix a bug with kernel boot emulation that would sometimes occur when using
  the release mode of the kernel.
* Fix the GIC device addresses the loader was using for QEMU during
  initialisation.
* Fixed a bug preventing allocating a MR at certain fixed physical addresses.
* Better error reporting when allocation of a memory region fails.
* Fix allocation of Scheduling Context objects, previously we were allocating
  more than necessary.

### Board support

* i.MX8MP-EVK
* Pine64 RockPro64
* Ariane (aka CVA6)
* Cheshire
* Raspberry Pi 4B

### Upgrade notes

There is a single breaking change in this release, it affects any
System Description Files (SDF) that make use of channels with PPCs.

This was done for two reasons:

1. It allows the tool to statically check and enforce the existing rule that a
   PD that performs a PPC must be lower priority that the PD it is calling into.
2. It allows finer granularity on the channel ends. For example, previously
   all channels allowed notifies either way, now that decision is up to the
   user. The default behaviour remains the same, both ends are allowed to
   notify each other.

To upgrade, follow these steps:

1. Remove the `pp` attribute from any PDs that have it.
2. Go to each channel with the PD that had the `pp` attribute. Set `pp="true"`
   on the end of the channel for the PD that is *performing* the PPC.

Below is an example of the upgrading a system that utilises PPCs.

From Microkit 1.4.1:
```xml
<protection_domain name="server" priority="254" pp="true">
    <program_image path="server.elf" />
</protection_domain>
<protection_domain name="client" priority="1">
    <program_image path="client.elf" />
</protection_domain>
<channel>
    <end pd="server" />
    <end pd="client" />
</channel>
```

To Microkit 2.0.0:
```xml
<protection_domain name="server" priority="254">
    <program_image path="server.elf" />
</protection_domain>
<protection_domain name="client" priority="1">
    <program_image path="client.elf" />
</protection_domain>
<channel>
    <end pd="server" />
    <end pd="client" pp="true" />
</channel>
```

Depending on your use-case you may also want to specify what end is allowed
to notify as well. For example, if the only communication between `server`
and `client` was PPC, you may want the channel to be the following:
```xml
<channel>
    <end pd="server" notify="false" />
    <end pd="client" notify="false" pp="true" />
</channel>
```

You can find all the details in the
[channel section of the manual](https://github.com/seL4/microkit/blob/2.0.0/docs/manual.md#channel).

## Release 1.4.1

This release contains various bug fixes. It does not include any new features.

* Fixed two bugs in the tool that lead to initialisation failure on larger Microkit systems.
* Disabled the `KernelArmVtimerUpdateVOffset` kernel configuration option by default.
  * This is necessary for Microkit VMs where they rely on knowing the actual surpassed time.
    More details are in the [pull request](https://github.com/seL4/microkit/pull/202).
* Enabled FPU for QEMU RISC-V virt and Pine64 Star64.
  * libmicrokit builds with hardware floating point enabled and, while it does not use the FPU,
    it means that every object linked with libmicrokit must also build with hardware floating
    point enabled. Previously using floating point operations would cause a crash in user-space.
* Fixed the loader link address for the MaaXBoard.
  * This does mean that if you target the MaaxBoard you will have to loader Microkit images at
    a different address. See the manual for details.
* Added error checking for overlapping memory regions.
* Included every TCB register in the monitor logs when a fault occurs.
* Made the tool compile from source with a Rust version lower that 1.79.0.
* Specified a minimum Rust version for the tool (1.73.0).
* Fixed typo in the `--help` output of the tool.
* Minor README fixes.
* Updated PyYAML dependency in requirements.txt to 6.0.2 (from 6.0).

## Release 1.4.0

This release aims to add support for requested features by the community, in order to
allow more people to use and transition to Microkit. There is of course still more to
be done over the next couple of releases.

This release has no breaking changes.

### Features added

* Added support for RISC-V 64-bit based platforms.
* Added a new 'benchmark' configuration to allow access to the in-kernel
  performance tracking.
* Add the ability to configure the stack size of a PD.
* Export ARM architectural timer to user-space for the QEMU virt AArch64 platform.
  * This platform does not have any other timer so this is allows having a timer
    driver when simulating/developing Microkit systems with QEMU.
* Add new APIs for 'deferred' versions of `microkit_notify` and `microkit_irq_ack`.
  See the manual for details on when and how to use these.

### Other changes

* Made a number of internal changes to the tool to improve performance and peak memory
  usage.
    * The tool's performance was not noticeable until building larger systems with Microkit.
      Now invoking the Microkit tool with a large system should not take more than 500ms-1s to
      complete. There are more opportunities for optimisation if we do run into the tool slowing
      down however.

### Bug fixes

* Fixed the loader to not print unless in debug mode (matching the behaviour of
  the kernel and monitor).
* Add error checking for duplicate symbols between `setvar_vaddr` attributes and
  `setvar` elements.
* Fixed an internal issue that prevented the Monitor from printing out correct fault
  information in debug mode.
* Fixed the parsing of parent protection domains, previously non-trivial cases were
  leading to errors.
* Fixed the tool to explicitly skip ELF segments that are not declared as loadable,
  previously the tool assumed all segments would be loaded at runtime.
* Fix permissions applied to the distributed/packaged SDK. Previously this would cause
  `sudo` access to move/remove the SDK.
* Fixed an internal issue that prevented a memory region from being allocated at a fixed
  physical address that is not part of device memory (e.g within RAM).

### Board support

This release adds support for the following platforms:

* QEMU virt (RISC-V 64-bit)
* Pine64 Star64

## Release 1.3.0

This release represents the first release since the seL4 Microkit was adopted by the
seL4 Foundation.

This release has no breaking changes.

### Features added

* Added support for 'passive' protection domains.
* Added protection domain hierarchy allowing PDs to manage faults caused by child PDs
  and control their execution.
* Added virtualisation support and a new 'virtual machine' abstraction that allows
  users to create systems with guest operating systems (such as Linux).
* Add the ability to specify the type of IRQ trigger on IRQ elements in the SDF. Previously
  all IRQs were registered as level triggered, now users are given the option of specifying
  an IRQ as 'edge' triggered which is needed for writing certain device drivers.
* Added support for building the Microkit SDK on macOS. If you are on macOS, you can now develop
  with Microkit without Docker or a virtual machine.

### Other changes

* Rewrote the Microkit tool from Python to Rust. This is meant to be a purely internal
  change and should not affect the use of the tool at all. This does however introduce
  a new dependency on Rust. See the README for building the new tool from source.
    * This was done primarily to decrease 3rd party dependencies and make it easier to build
      the Microkit SDK from source.

### Bug fixes

* Fixed the libmicrokit linker script to work with the LLVM linker, LLD. This means that non-GCC
  build systems can link with libmicrokit.
* Removed compiler provided includes (such as stdint.h and stdbool.h) from libmicrokit. This means
  that the libmicrokit header no longer depends on any system provided headers, making the SDK
  more self-contained.
* Various fixes and improvements to the manual.
* Various other bug-fixes and error message improvements to the Microkit tool.

### Board support

This release adds support for the following platforms:

* Avnet MaaXBoard
* HardKernel Odroid-C2
* HardKernel Odroid-C4
* NXP i.MX8MM-EVK
* NXP i.MX8MQ-EVK
* QEMU virt (AArch64)
* Xilinx ZCU102
